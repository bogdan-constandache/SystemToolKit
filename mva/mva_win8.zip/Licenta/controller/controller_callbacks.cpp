#include "controller_callbacks.h"

QStandardItemModel *GetComputerGeneralInformations()
{
    QStandardItemModel *pModel = 0;



    return pModel;
}

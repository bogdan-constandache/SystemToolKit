#ifndef _CONTROLLER_CALLBACKS_
#define _CONTROLLER_CALLBACKS_

#include <QStandardItemModel>

QStandardItemModel *GetComputerGeneralInformations();

#endif

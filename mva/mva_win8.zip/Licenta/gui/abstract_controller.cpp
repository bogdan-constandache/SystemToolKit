#include "abstract_controller.h"

AbstractController::AbstractController(QObject *parent) :
    QObject(parent)
{
}
